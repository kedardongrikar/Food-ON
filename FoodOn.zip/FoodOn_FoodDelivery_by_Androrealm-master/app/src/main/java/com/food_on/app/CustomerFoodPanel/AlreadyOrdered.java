package com.food_on.app.CustomerFoodPanel;

public class AlreadyOrdered {

   private String isOrdered;

    public AlreadyOrdered(String isOrdered) {
        this.isOrdered = isOrdered;
    }

    public AlreadyOrdered()
    {

    }

    public String getIsOrdered() {
        return isOrdered;
    }

    public void setIsOrdered(String isOrdered) {
        this.isOrdered = isOrdered;
    }
}
